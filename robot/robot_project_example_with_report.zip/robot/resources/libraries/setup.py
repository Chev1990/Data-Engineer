from setuptools import setup

setup(name='rf_dq_test_libs',
      version=1.0,
      py_modules=['AwsServices', 'Utils'],
      )
